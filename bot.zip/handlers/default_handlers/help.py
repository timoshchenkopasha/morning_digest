import telebot
from telebot.types import Message

from config import bot


@bot.message_handler(commands=['help'])
def help_handler(message: Message) -> None:
    """Показывает все доступные команды бота"""

    help_text = """<b>🚀 MorningDigest — ТВОË НАЧАЛО ДНЯ! ⚡</b>

• <b>8:00 УТРА</b> → 📰 новости + 🌅 погода
• <b>ИГРА!</b> → пачки новостей = 📈 уровни + 🔥 серия дней подряд 
• <b>СВЕЖИЕ НОВОСТИ</b> → 5 новостей с фотками 
• <b>ПРОФИЛЬ</b> → смотри свой прогресс как в игре 🎮

<b>🎮 ДОСТУПНЫЕ КОМАНДЫ:</b>
<code>/start</code> — 🏙️ Выбери город (погода персональная!)
<code>/digest</code> — 📰 <b>Следующая пачка</b> новостей 
<code>/profile</code> — 📊 <b>Твоя статистика</b> (уровни+серия)
<code>/help</code> — ❓ Возможности бота

<b>🏆 УРОВНИ ПРОГРЕССА:</b>
🌱 <b>Читатель</b> → 1 пачка/день
📈 <b>Активный</b> → 2 пачки  
🌟 <b>Профи дня</b> → 3+ пачки!
🔥 <b>Серия</b> → сколько дней подряд?!

<b>⚡ Как начать? (30 сек):</b>
1️⃣ <code>/start</code> → Minsk/Москва/Другой
2️⃣ <b>07:00 - рассылка</b> или <code>/digest</code> НОВОСТИ СЕЙЧАС

<i>💬 НАЧНЕМ! 💪</i>"""

    bot.send_message(
        message.chat.id,
        help_text,
        parse_mode='HTML'
    )
