from .api import news_api, weather_api
from .html import news_parser
